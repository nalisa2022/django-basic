from unittest.util import _MAX_LENGTH
from django.db import models

# Create your models here.
from django.db import models

# Create your models here.
class helloworld(models.Model):
    text=models.CharField(max_length=255, null=False)